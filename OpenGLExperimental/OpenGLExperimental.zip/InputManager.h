#pragma once
class InputManager
{
public:
	unsigned char forward = 'w';
	//buraya keyler atan�cak mesela forward falan f�lan vs.
};

