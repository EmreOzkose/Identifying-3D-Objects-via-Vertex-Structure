#pragma once
#include <Angel_commons/Angel.h>

class Vector3
{
public:
	static vec3 FORWARD;
	static vec3 RIGHT;
	static vec3 UP;

};