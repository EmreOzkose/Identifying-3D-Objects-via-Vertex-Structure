#pragma once

class Renderer
{
public:
	static void Display(void(*func)(void));

};
