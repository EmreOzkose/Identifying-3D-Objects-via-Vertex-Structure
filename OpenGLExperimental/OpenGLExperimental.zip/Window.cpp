#include <Angel_commons/Angel.h>
#include "Window.h"


void Window::Init(unsigned int mode,vec2 windowPosition,vec2 windowSize)
{
	glutInitDisplayMode(mode);
	glutInitWindowPosition(windowPosition.x, windowPosition.y);
	glutInitWindowSize(windowSize.x, windowSize.y);
}

void Window::Show(const char* windowName)
{
	glutCreateWindow(windowName);
	glewExperimental = GL_TRUE;
	glewInit();
}

