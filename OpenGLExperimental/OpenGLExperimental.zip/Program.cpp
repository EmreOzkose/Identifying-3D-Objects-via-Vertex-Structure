#include "Program.h"
#include <Angel_commons/Angel.h>

void Program::Init(int argc,char **argv)
{
	glutInit(&argc, argv);
}


