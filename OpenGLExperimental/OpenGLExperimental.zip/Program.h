#pragma once
#include "Camera.h"
#include "Window.h"
#include "Renderer.h"
#include "InputManager.h"
#include "Vector3.h"
class Program
{
public:
	void Init(int argc, char **argv);

};

