#include "Vector3.h"

vec3 Vector3::FORWARD = vec3(0, 0, 1);
vec3 Vector3::RIGHT = vec3(1, 0, 0);
vec3 Vector3::UP = vec3(0, 1, 0);